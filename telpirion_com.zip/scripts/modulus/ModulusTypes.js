var Modulus;
(function (Modulus) {
    var Types;
    (function (Types) {
        ;
        ;
        (function (GameState) {
            GameState[GameState["Menu"] = 0] = "Menu";
            GameState[GameState["Playing"] = 1] = "Playing";
            GameState[GameState["CreateCharacter"] = 2] = "CreateCharacter"; // 2
        })(Types.GameState || (Types.GameState = {}));
        var GameState = Types.GameState;
        ;
    })(Types = Modulus.Types || (Modulus.Types = {}));
})(Modulus || (Modulus = {}));
//# sourceMappingURL=ModulusTypes.js.map